import { motion, AnimatePresence } from 'framer-motion';
import { RadioPlayer } from './RadioPlayer';
import { useState } from 'react';

export const FloatingPlayer = () => {
  const [isVisible, setIsVisible] = useState(true);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0, opacity: 0 }}
          className="fixed bottom-4 right-4 z-50"
        >
          <RadioPlayer compact />
        </motion.div>
      )}
    </AnimatePresence>
  );
};
