import { Link } from 'wouter';
import { Radio, Phone, Building, Mail, MapPin, Facebook, Twitter } from 'lucide-react';
import { CONTACT_INFO, SOCIAL_LINKS } from '@/lib/constants';

export const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Station Info */}
          <div className="col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center">
                <Radio className="text-white w-6 h-6" />
              </div>
              <div>
                <h3 className="font-inter font-bold text-xl">Crescent Community Radio</h3>
                <p className="text-gray-400">97.0FM - Rochdale</p>
              </div>
            </div>
            <p className="text-gray-300 mb-4 max-w-md">
              Rochdale's first and only full-time community radio station, broadcasting 24/7 to serve our diverse local community.
            </p>
            <p className="text-sm text-gray-400">
              Charity Number: 1126088
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/" className="text-gray-300 hover:text-white transition-colors">Home</Link></li>
              <li><Link href="/about" className="text-gray-300 hover:text-white transition-colors">About Us</Link></li>
              <li><Link href="/schedule" className="text-gray-300 hover:text-white transition-colors">Schedule</Link></li>
              <li><Link href="/presenters" className="text-gray-300 hover:text-white transition-colors">Presenters</Link></li>
              <li><Link href="/contact" className="text-gray-300 hover:text-white transition-colors">Contact</Link></li>
            </ul>
          </div>
          
          {/* Contact Summary */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-primary" />
                <span>Studio: {CONTACT_INFO.studio.phone}</span>
              </li>
              <li className="flex items-center space-x-2">
                <Building className="w-4 h-4 text-primary" />
                <span>Office: {CONTACT_INFO.office.phone}</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-primary" />
                <span>{CONTACT_INFO.office.email}</span>
              </li>
              <li className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-primary" />
                <span>Rochdale, UK</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2025 Crescent Community Radio. All rights reserved.
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href={SOCIAL_LINKS.facebook} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Facebook className="w-5 h-5" />
            </a>
            <a href={SOCIAL_LINKS.twitter} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Twitter className="w-5 h-5" />
            </a>
            <a href={SOCIAL_LINKS.mixcloud} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Radio className="w-5 h-5" />
            </a>
            <a href={SOCIAL_LINKS.tunein} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Radio className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
