import { ReactNode } from 'react';
import { Navigation } from './Navigation';
import { Footer } from './Footer';
import { FloatingPlayer } from './FloatingPlayer';

interface LayoutProps {
  children: ReactNode;
}

export const Layout = ({ children }: LayoutProps) => {
  return (
    <div className="min-h-screen font-poppins bg-gradient-to-br from-blue-50 to-indigo-100">
      <Navigation />
      <main className="pt-16">
        {children}
      </main>
      <Footer />
      <FloatingPlayer />
    </div>
  );
};
