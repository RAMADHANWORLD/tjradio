
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Pencil, Save, X, Plus } from 'lucide-react';

interface Presenter {
  id: string;
  name: string;
  role: string;
  shows: string;
  bio: string;
  image: string;
}

interface PresenterEditorProps {
  presenters: Presenter[];
  onUpdate: (presenters: Presenter[]) => void;
  onLogout: () => void;
}

export const PresenterEditor = ({ presenters, onUpdate, onLogout }: PresenterEditorProps) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editData, setEditData] = useState<Partial<Presenter>>({});

  const handleEdit = (presenter: Presenter) => {
    setEditingId(presenter.id);
    setEditData(presenter);
  };

  const handleSave = async () => {
    if (!editingId || !editData) return;

    try {
      const response = await fetch('/api/presenters', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: JSON.stringify({ id: editingId, ...editData }),
      });

      if (response.ok) {
        const updatedPresenters = presenters.map(p => 
          p.id === editingId ? { ...p, ...editData } : p
        );
        onUpdate(updatedPresenters);
        setEditingId(null);
        setEditData({});
      }
    } catch (err) {
      console.error('Failed to update presenter');
    }
  };

  const handleCancel = () => {
    setEditingId(null);
    setEditData({});
  };

  const handleAddNew = () => {
    const newId = `presenter_${Date.now()}`;
    setEditingId(newId);
    setEditData({
      id: newId,
      name: '',
      role: '',
      shows: '',
      bio: '',
      image: '/placeholder.jpg'
    });
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this presenter?')) return;

    try {
      const response = await fetch(`/api/presenters/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`,
        },
      });

      if (response.ok) {
        const updatedPresenters = presenters.filter(p => p.id !== id);
        onUpdate(updatedPresenters);
      }
    } catch (err) {
      console.error('Failed to delete presenter');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Manage Presenters</h2>
        <div className="space-x-2">
          <Button onClick={handleAddNew}>
            <Plus className="w-4 h-4 mr-2" />
            Add New
          </Button>
          <Button variant="outline" onClick={onLogout}>
            Logout
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {presenters.map((presenter) => (
          <Card key={presenter.id} className="relative">
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                {editingId === presenter.id ? (
                  <Input
                    value={editData.name || ''}
                    onChange={(e) => setEditData({...editData, name: e.target.value})}
                    placeholder="Presenter Name"
                  />
                ) : (
                  presenter.name
                )}
                {editingId === presenter.id ? (
                  <div className="flex space-x-1">
                    <Button size="sm" onClick={handleSave}>
                      <Save className="w-3 h-3" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={handleCancel}>
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ) : (
                  <Button size="sm" variant="outline" onClick={() => handleEdit(presenter)}>
                    <Pencil className="w-3 h-3" />
                  </Button>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <label className="text-sm font-medium">Role:</label>
                {editingId === presenter.id ? (
                  <Input
                    value={editData.role || ''}
                    onChange={(e) => setEditData({...editData, role: e.target.value})}
                    placeholder="Role"
                  />
                ) : (
                  <p className="text-sm">{presenter.role}</p>
                )}
              </div>
              
              <div>
                <label className="text-sm font-medium">Shows:</label>
                {editingId === presenter.id ? (
                  <Input
                    value={editData.shows || ''}
                    onChange={(e) => setEditData({...editData, shows: e.target.value})}
                    placeholder="Shows"
                  />
                ) : (
                  <p className="text-sm">{presenter.shows}</p>
                )}
              </div>

              <div>
                <label className="text-sm font-medium">Bio:</label>
                {editingId === presenter.id ? (
                  <Textarea
                    value={editData.bio || ''}
                    onChange={(e) => setEditData({...editData, bio: e.target.value})}
                    placeholder="Bio"
                    rows={3}
                  />
                ) : (
                  <p className="text-xs">{presenter.bio}</p>
                )}
              </div>

              <div>
                <label className="text-sm font-medium">Image URL:</label>
                {editingId === presenter.id ? (
                  <Input
                    value={editData.image || ''}
                    onChange={(e) => setEditData({...editData, image: e.target.value})}
                    placeholder="Image URL"
                  />
                ) : (
                  <p className="text-xs">{presenter.image}</p>
                )}
              </div>

              {editingId !== presenter.id && (
                <Button 
                  variant="destructive" 
                  size="sm" 
                  onClick={() => handleDelete(presenter.id)}
                  className="w-full mt-2"
                >
                  Delete
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};
