import { Play, Pause, VolumeX, Volume2, Loader2 } from 'lucide-react';
import { useAudioPlayer } from '@/hooks/useAudioPlayer';
import { motion } from 'framer-motion';

interface RadioPlayerProps {
  compact?: boolean;
}

export const RadioPlayer = ({ compact = false }: RadioPlayerProps) => {
  const { isPlaying, volume, isLoading, error, togglePlay, adjustVolume } = useAudioPlayer();

  const EqualizerBars = () => (
    <div className="flex justify-center space-x-1">
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="equalizer-bar w-1 bg-gradient-to-t from-secondary to-green-400 rounded-full"
          animate={isPlaying ? { height: ['0.5rem', '2rem', '0.5rem'] } : { height: '0.5rem' }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            delay: i * 0.2,
            ease: 'easeInOut'
          }}
        />
      ))}
    </div>
  );

  if (compact) {
    return (
      <div className="glass-dark rounded-full p-4 shadow-2xl">
        <button 
          className="w-12 h-12 bg-gradient-to-r from-red-500 to-red-600 rounded-full flex items-center justify-center text-white hover:scale-110 transition-transform disabled:opacity-50"
          onClick={togglePlay}
          disabled={isLoading}
        >
          {isLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : isPlaying ? (
            <Pause className="w-5 h-5" />
          ) : (
            <Play className="w-5 h-5 ml-0.5" />
          )}
        </button>
      </div>
    );
  }

  return (
    <div className="glass rounded-2xl p-6 shadow-2xl">
      <div className="text-center space-y-4">
        <div className="mb-4">
          <EqualizerBars />
        </div>
        
        <div className="text-white">
          <h3 className="font-semibold text-lg">Now Playing</h3>
          <p className="text-blue-200">Community Hour with Local Voices</p>
          <p className="text-sm text-blue-300">Faheem Ahmed</p>
        </div>
        
        {error && (
          <div className="text-red-300 text-sm bg-red-500/20 rounded-lg p-2">
            {error}
          </div>
        )}
        
        {/* Player Controls */}
        <div className="flex items-center justify-center space-x-6 mt-6">
          <button 
            className="text-white hover:text-yellow-400 transition-colors disabled:opacity-50"
            onClick={() => adjustVolume(volume - 0.1)}
            disabled={volume <= 0}
          >
            <VolumeX className="w-5 h-5" />
          </button>
          <button 
            className="w-16 h-16 bg-gradient-to-r from-red-500 to-red-600 rounded-full flex items-center justify-center text-white text-2xl hover:scale-105 transition-transform shadow-lg disabled:opacity-50"
            onClick={togglePlay}
            disabled={isLoading}
          >
            {isLoading ? (
              <Loader2 className="w-6 h-6 animate-spin" />
            ) : isPlaying ? (
              <Pause className="w-6 h-6" />
            ) : (
              <Play className="w-6 h-6 ml-1" />
            )}
          </button>
          <button 
            className="text-white hover:text-yellow-400 transition-colors disabled:opacity-50"
            onClick={() => adjustVolume(volume + 0.1)}
            disabled={volume >= 1}
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </div>
        
        {/* Volume Slider */}
        <div className="flex items-center space-x-3 mt-4">
          <VolumeX className="text-white w-4 h-4" />
          <div className="flex-1 h-2 bg-white/20 rounded-full">
            <div 
              className="h-full bg-gradient-to-r from-secondary to-green-400 rounded-full transition-all"
              style={{ width: `${volume * 100}%` }}
            />
          </div>
          <Volume2 className="text-white w-4 h-4" />
        </div>
      </div>
    </div>
  );
};
