export const RADIO_STREAM_URL = "https://radio.canstream.co.uk:8152/live.mp3";

export const CONTACT_INFO = {
  studio: {
    phone: "01706 340786",
    text: "07456 340786",
    email: "studio@crescentradio.net",
    whatsapp: "447456340786"
  },
  office: {
    phone: "01706 340385",
    email: "info@crescentradio.net"
  },
  sales: {
    email: "faheem@crescentradio.net",
    phone: "07884 053544"
  }
};

export const SOCIAL_LINKS = {
  facebook: "https://www.facebook.com/CrescentRadio",
  twitter: "https://twitter.com/crescentradio",
  mixcloud: "https://www.mixcloud.com/CrescentCommunityRadio/",
  tunein: "https://tunein.com/radio/Crescent-Radio-970-s67851/"
};

export const PRESENTERS = [
  {
    id: 1,
    name: "Mufti Saab",
    role: "Religious Affairs Presenter",
    shows: "Q&A with Mufti Saab: Wed 1.30-3pm",
    bio: "Regular guest in Crescent Radio's Question and Answer show where listeners can ask for religious guidance on various topics. Using extensive knowledge on the Qur'an, A-Hadith and Sunnah of the Prophet.",
    image: "https://i0.wp.com/www.crescentradio.net/wp-content/uploads/DSCF3084-150x150.jpg?resize=111%2C105&ssl=1"
  },
  {
    id: 2,
    name: "Noaman Hayee",
    role: "Talk Show Host",
    shows: "Gup Shup: Thurs 7-9pm",
    bio: "Local businessman bringing everyday topics affecting people throughout Rochdale to the airwaves in his own inimitable style. Mixing masala and hand picked tracks with social and cultural meaning.",
    image: "https://i0.wp.com/cr.techtyle.com/wp-content/uploads/2009/07/IMG_18341-150x150.jpg?resize=122%2C122"
  },
  {
    id: 3,
    name: "Humera Haqqani",
    role: "News Presenter",
    shows: "Crescent NewsRound: Fri 10am – Noon",
    bio: "Karachi born mother of 4 and successful entrepreneur. Trilingual homemaker with special interest in Pakistani politics and Islamic history. Also a driving instructor with interests in badminton and poetry.",
    image: "https://i0.wp.com/www.crescentradio.net/images/presenters/Razia-Shamim.jpg?resize=91%2C129&ssl=1"
  },
  {
    id: 4,
    name: "Abdur Rehman Hussain",
    role: "Multi-Show Presenter",
    shows: "Light upon Light: Saturdays 3-6pm, Youth Show: Thursdays 7pm, Drive Time: Tues/Wed",
    bio: "Multi-talented team member and keen sportsman. Light Upon Light includes riddles, Islamic teachings, Al-Akhira, Qur'an translation, Tilawah and reflections.",
    image: "https://i0.wp.com/cr.techtyle.com/wp-content/uploads/2009/07/no-pic1-150x150.jpg?resize=150%2C150"
  },
  {
    id: 5,
    name: "Heena Jabeen",
    role: "Community Show Host",
    shows: "Mix Masala: Wednesdays 12-2pm",
    bio: "Avid film and television enthusiast, final year Beautician student. The Mix Masala contains Naats, Nasheeds, requests, cultural discussions, recipes, household and beauty tips.",
    image: "https://i0.wp.com/www.crescentradio.net/wp-content/uploads/no-pic-150x150.jpg?resize=94%2C100&ssl=1"
  },
  {
    id: 6,
    name: "Afzal Naqshabandi",
    role: "Naat Show Host",
    shows: "The Madni Aaqa Naat Show: Mon 7-9pm",
    bio: "Former Naat Competition winner who now hosts the competition himself. Showcases hidden talent from Rochdale streets, encouraging local Naat Khwaans to recite praises live on air.",
    image: "https://i0.wp.com/www.crescentradio.net/images/presenters/Afzal.jpg?resize=92%2C120&ssl=1"
  },
  {
    id: 7,
    name: "Haji Farooq & Hafiz Rafaqat Ahmad",
    role: "Mirpuri Programme Presenters",
    shows: "Roshni: Sun 7-9pm",
    bio: "Dynamic duo presenting Crescent's Mirpuri programme with live recitals in Potwhari by local artists. Reaches out to Rochdale's strong Mirpuri community in their mother tongue.",
    image: "https://i0.wp.com/www.crescentradio.net/images/presenters/Raf%26Far.jpg?resize=115%2C86&ssl=1"
  },
  {
    id: 8,
    name: "Norman Warwick & Steve Bewick",
    role: "Arts Programme Co-Presenters",
    shows: "All Across The Arts: Tues 9pm",
    bio: "Norman is a widely published poet and writer with vast broadcasting experience. Steve is a jazz fan with community broadcasting experience and sound editing expertise.",
    image: "https://i0.wp.com/cr.techtyle.com/wp-content/uploads/2009/07/no-pic1-150x150.jpg?resize=150%2C150"
  },
  {
    id: 9,
    name: "Saba Nusrat",
    role: "Poetry Show Host",
    shows: "Sab Rang: Tues 8-10pm",
    bio: "Renowned Urdu poet with many books. Brings soothing late night poetry show with journey through Urdu Shayari and Ghazals served up in dulcet tones.",
    image: "https://i0.wp.com/www.crescentradio.net/wp-content/uploads/no-pic-150x150.jpg?resize=101%2C98&ssl=1"
  },
  {
    id: 10,
    name: "Razia Shamim MBE",
    role: "Community Affairs Presenter",
    shows: "Age Concern: Wed 10am-1pm",
    bio: "Worked in Rochdale community for over thirty years. Presents Age Concern show with natural home remedies, news, interviews and tried and tested recipes.",
    image: "https://i0.wp.com/www.crescentradio.net/wp-content/uploads/no-pic-150x150.jpg?resize=107%2C108&ssl=1"
  },
  {
    id: 11,
    name: "Nafisa & Rahat Siddique",
    role: "Children's Show Presenters",
    shows: "Kids Korner: Sat 9am-12pm",
    bio: "Bring Saturday morning Kids Korner show tailored for children. Fun packed show full of riddles, jokes, quizzes and favourite Nasheed requests.",
    image: "https://i0.wp.com/www.crescentradio.net/wp-content/uploads/no-pic-150x150.jpg?resize=109%2C101&ssl=1"
  },
  {
    id: 12,
    name: "Sabira & Shahida",
    role: "Health Show Presenters",
    shows: "Community Health Show: Thurs 10am-1pm",
    bio: "Mix Naats and Nasheeds alongside healthy living advice and informative discussion. Include interactive segments where listeners can call for advice and guidance.",
    image: "https://i0.wp.com/www.crescentradio.net/wp-content/uploads/no-pic-150x150.jpg?resize=114%2C106&ssl=1"
  },
  {
    id: 13,
    name: "Muhammad Afzal",
    role: "Cultural & News Presenter",
    shows: "Phullan dey Rang: Wed 9-11pm, Crescent Khabarnama: Thurs 6pm",
    bio: "Local man with keen interest in current affairs and Pakistani culture. Presents Urdu language news and Punjabi cultural show bringing all colors of Punjab.",
    image: "https://i0.wp.com/www.crescentradio.net/wp-content/uploads/no-pic-150x150.jpg?resize=110%2C108&ssl=1"
  },
  {
    id: 14,
    name: "Qari Muhammad Abbas",
    role: "Islamic Programme Presenter",
    shows: "Islamic Programme: Fridays 12-2pm",
    bio: "Brings enlightening Islamic programme with stories of the Prophet, verses of the Qur'an and A'Hadith plus requests and dedications. Unique opportunity to renew faith and expand knowledge.",
    image: "https://i0.wp.com/www.crescentradio.net/wp-content/uploads/no-pic-150x150.jpg?resize=104%2C106&ssl=1"
  },
  {
    id: 15,
    name: "Baji Yasmeen",
    role: "Magazine Show Host",
    shows: "Chamak: Sun 5-7pm",
    bio: "Weekly magazine show including mixture of requests, favourite Naats and Nasheeds, plus topical discussion and debate to keep listeners entertained and enthralled.",
    image: "https://i0.wp.com/www.crescentradio.net/wp-content/uploads/no-pic-150x150.jpg?resize=105%2C104&ssl=1"
  },
  {
    id: 16,
    name: "Dr Musharraf Husain & Dobir Miah",
    role: "Bangla Programme Presenters",
    shows: "Boishakhi Bangla Show: Wed 7-9pm",
    bio: "Dr Musharraf is a GP serving Rochdale for 30+ years. Dobir is self-employed youth & community worker. Features Bangla music, naat, nasheeds, culture and community debates.",
    image: "https://i0.wp.com/cr.techtyle.com/wp-content/uploads/2012/07/drhussain_pic-290x300.jpg?resize=95%2C99"
  }
];

export const SCHEDULE_DATA = [
  {
    day: "Monday",
    shows: [
      { time: "7:00 PM", name: "The Madni Aaqa Naat Show", type: "With Afzal Naqshabandi", color: "primary" }
    ]
  },
  {
    day: "Tuesday",
    shows: [
      { time: "8:00 PM", name: "Sab Rang", type: "Urdu Poetry with Saba Nusrat", color: "purple" },
      { time: "9:00 PM", name: "All Across The Arts", type: "With Norman Warwick & Steve Bewick", color: "accent" }
    ]
  },
  {
    day: "Wednesday",
    shows: [
      { time: "10:00 AM", name: "Age Concern", type: "With Razia Shamim MBE", color: "green" },
      { time: "12:00 PM", name: "Mix Masala", type: "With Heena Jabeen", color: "secondary" },
      { time: "1:30 PM", name: "Q&A with Mufti Saab", type: "Religious Guidance", color: "primary" },
      { time: "7:00 PM", name: "Boishakhi Bangla Show", type: "Dr Musharraf & Dobir Miah", color: "blue" },
      { time: "9:00 PM", name: "Phullan dey Rang", type: "Punjabi with Muhammad Afzal", color: "orange" }
    ]
  },
  {
    day: "Thursday",
    shows: [
      { time: "10:00 AM", name: "Community Health Show", type: "With Sabira & Shahida", color: "green" },
      { time: "6:00 PM", name: "Crescent Khabarnama", type: "Urdu News with Muhammad Afzal", color: "blue" },
      { time: "7:00 PM", name: "Youth Show", type: "With Abdur Rehman Hussain", color: "accent" },
      { time: "7:00 PM", name: "Gup Shup", type: "With Noaman Hayee", color: "secondary" }
    ]
  },
  {
    day: "Friday",
    shows: [
      { time: "10:00 AM", name: "Crescent NewsRound", type: "With Humera Haqqani", color: "primary" },
      { time: "12:00 PM", name: "Islamic Programme", type: "With Qari Muhammad Abbas", color: "primary" }
    ]
  },
  {
    day: "Saturday",
    shows: [
      { time: "9:00 AM", name: "Kids Korner", type: "With Nafisa & Rahat Siddique", color: "accent" },
      { time: "3:00 PM", name: "Light Upon Light", type: "With Abdur Rehman Hussain", color: "primary" }
    ]
  },
  {
    day: "Sunday",
    shows: [
      { time: "5:00 PM", name: "Chamak", type: "Magazine Show with Baji Yasmeen", color: "purple" },
      { time: "7:00 PM", name: "Roshni", type: "Mirpuri with Haji Farooq & Hafiz Rafaqat", color: "orange" }
    ]
  }
];
