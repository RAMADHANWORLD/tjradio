import { motion } from 'framer-motion';
import { Phone, Mail, Users, Radio, Heart, Award } from 'lucide-react';
import { CONTACT_INFO } from '@/lib/constants';

export const About = () => {
  const features = [
    {
      icon: Radio,
      title: '24/7 Broadcasting',
      description: 'Continuous programming serving our community around the clock on 97.0FM and online.'
    },
    {
      icon: Users,
      title: 'Community Focused',
      description: 'Serving approximately 19,000 Muslims in Rochdale while welcoming all community members.'
    },
    {
      icon: Heart,
      title: 'Volunteer Driven',
      description: 'Powered by passionate volunteers with full training provided for all new members.'
    },
    {
      icon: Award,
      title: 'Registered Charity',
      description: 'Operating as Charity 1126088, dedicated to community service and engagement.'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-primary/10 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-inter font-bold text-4xl md:text-5xl text-gray-900 mb-6">
              About Crescent Community Radio
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              Welcome to the online home of Crescent Community Radio; Rochdale's first and only full time station broadcasting 24 hours a day, seven days a week on 97.0FM and www.crescentradio.net.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Modern radio studio equipment" 
                className="rounded-2xl shadow-2xl w-full"
              />
            </motion.div>
            
            <motion.div 
              className="space-y-6"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <h2 className="font-inter font-bold text-3xl text-gray-900">Our Mission</h2>
              <p className="text-gray-600 leading-relaxed">
                There's a lot going on at the moment at Crescent Radio, so take a few moments to browse our website to see just some of the latest stories unfolding at the station.
              </p>
              <p className="text-gray-600 leading-relaxed">
                We focus on serving the local Muslim community while welcoming participation from all community members. Our content ranges from religious shows to general community interest, broadcasting in English and other community languages.
              </p>
              <div className="bg-gradient-to-r from-primary/10 to-blue-50 p-6 rounded-xl">
                <h3 className="font-semibold text-lg text-gray-900 mb-2">Broadcasting Details</h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• Frequency: 97.0FM (terrestrial)</li>
                  <li>• Online streaming via website and radio platforms</li>
                  <li>• Service area: Rochdale and surrounding Metropolitan Borough</li>
                  <li>• Content: Religious programming, local news, community packages</li>
                </ul>
              </div>
            </motion.div>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                className="bg-gradient-to-br from-white to-blue-50 rounded-2xl p-6 shadow-lg text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="text-white w-8 h-8" />
                </div>
                <h3 className="font-semibold text-xl text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Get Involved Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="font-inter font-bold text-3xl md:text-4xl text-gray-900 mb-6">
              Want to Get Involved?
            </h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              If you would like to get involved in Crescent Community Radio then what are you waiting for? Maybe you'd like to present a show, or even help out behind the scenes. Full training will be provided and previous experience is not necessary.
            </p>
            
            <div className="bg-white rounded-2xl p-8 shadow-xl max-w-2xl mx-auto">
              <h3 className="font-semibold text-xl text-gray-900 mb-6">Contact Us Today</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <a 
                  href={`tel:${CONTACT_INFO.office.phone}`}
                  className="flex items-center justify-center space-x-3 bg-primary text-white px-6 py-4 rounded-lg hover:bg-primary/90 transition-colors"
                >
                  <Phone className="w-5 h-5" />
                  <span className="font-semibold">{CONTACT_INFO.office.phone}</span>
                </a>
                <a 
                  href={`mailto:${CONTACT_INFO.office.email}`}
                  className="flex items-center justify-center space-x-3 bg-secondary text-white px-6 py-4 rounded-lg hover:bg-secondary/90 transition-colors"
                >
                  <Mail className="w-5 h-5" />
                  <span className="font-semibold">{CONTACT_INFO.office.email}</span>
                </a>
              </div>
              
              <div className="mt-6 p-4 bg-accent/10 rounded-lg">
                <p className="text-sm text-gray-700">
                  <strong>Opportunities available:</strong> Radio presenting, technical support, community outreach, content creation, and administrative assistance.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};
