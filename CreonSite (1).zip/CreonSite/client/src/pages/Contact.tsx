import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, MessageSquare, Building, Radio, Facebook, Twitter } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { CONTACT_INFO, SOCIAL_LINKS } from '@/lib/constants';

const contactFormSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Valid email is required'),
  subject: z.string().optional(),
  message: z.string().min(1, 'Message is required'),
  consent: z.boolean().refine(val => val === true, 'You must give consent to submit')
});

type ContactFormData = z.infer<typeof contactFormSchema>;

export const Contact = () => {
  const { toast } = useToast();
  
  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: '',
      email: '',
      subject: '',
      message: '',
      consent: false
    }
  });

  const onSubmit = async (data: ContactFormData) => {
    try {
      // Here you would typically send the data to your backend
      console.log('Contact form data:', data);
      
      toast({
        title: 'Message sent successfully!',
        description: 'Thank you for your message. We\'ll get back to you soon.',
      });
      
      form.reset();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send message. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const contactSections = [
    {
      title: 'Live Studio',
      icon: Radio,
      iconColor: 'text-red-500',
      contacts: [
        { icon: Phone, label: 'Studio Line', value: CONTACT_INFO.studio.phone, href: `tel:${CONTACT_INFO.studio.phone}`, color: 'text-primary' },
        { icon: MessageSquare, label: 'Text Line', value: CONTACT_INFO.studio.text, href: `tel:${CONTACT_INFO.studio.text}`, color: 'text-secondary' },
        { icon: Mail, label: 'Studio Email', value: CONTACT_INFO.studio.email, href: `mailto:${CONTACT_INFO.studio.email}`, color: 'text-accent' },
        { icon: MessageSquare, label: 'WhatsApp', value: CONTACT_INFO.studio.text, href: `https://api.whatsapp.com/send?phone=${CONTACT_INFO.studio.whatsapp}&text=Hi%2C%20I%20got%20your%20WhatsApp%20information%20from%20your%20website.`, color: 'text-green-600' }
      ]
    },
    {
      title: 'Back Office',
      icon: Building,
      iconColor: 'text-blue-500',
      contacts: [
        { icon: Phone, label: 'Main Office', value: CONTACT_INFO.office.phone, href: `tel:${CONTACT_INFO.office.phone}`, color: 'text-primary' },
        { icon: Mail, label: 'General Enquiries', value: CONTACT_INFO.office.email, href: `mailto:${CONTACT_INFO.office.email}`, color: 'text-purple-600' },
        { icon: Mail, label: 'Sales & Partnerships', value: CONTACT_INFO.sales.email, href: `mailto:${CONTACT_INFO.sales.email}`, color: 'text-orange-600' },
        { icon: Phone, label: 'Sales Tel', value: CONTACT_INFO.sales.phone, href: `tel:${CONTACT_INFO.sales.phone}`, color: 'text-orange-600' }
      ]
    }
  ];

  return (
    <div className="min-h-screen py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="font-inter font-bold text-4xl md:text-5xl text-gray-900 mb-4">Get In Touch</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">Have a question, want to share feedback, or interested in getting involved? We'd love to hear from you.</p>
        </motion.div>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            {contactSections.map((section, sectionIndex) => (
              <motion.div
                key={section.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: sectionIndex * 0.1 }}
              >
                <Card>
                  <CardContent className="p-8">
                    <h3 className="font-semibold text-xl text-gray-900 mb-6 flex items-center">
                      <section.icon className={`${section.iconColor} mr-3 w-6 h-6`} />
                      {section.title}
                    </h3>
                    <div className="space-y-4">
                      {section.contacts.map((contact, contactIndex) => (
                        <div key={contactIndex} className="flex items-center space-x-4">
                          <div className={`w-12 h-12 ${contact.color.replace('text-', 'bg-')}/10 rounded-full flex items-center justify-center`}>
                            <contact.icon className={`${contact.color} w-5 h-5`} />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{contact.label}</p>
                            <a href={contact.href} className={`${contact.color} hover:opacity-80 font-semibold transition-colors`}>
                              {contact.value}
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
            
            {/* Social Media Links */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Card>
                <CardContent className="p-8">
                  <h3 className="font-semibold text-xl text-gray-900 mb-6 flex items-center">
                    <MessageSquare className="text-green-500 mr-3 w-6 h-6" />
                    Follow Us
                  </h3>
                  <div className="flex space-x-4">
                    <a href={SOCIAL_LINKS.facebook} target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-blue-500 hover:bg-blue-600 rounded-full flex items-center justify-center text-white transition-colors">
                      <Facebook className="w-5 h-5" />
                    </a>
                    <a href={SOCIAL_LINKS.twitter} target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-blue-400 hover:bg-blue-500 rounded-full flex items-center justify-center text-white transition-colors">
                      <Twitter className="w-5 h-5" />
                    </a>
                    <a href={SOCIAL_LINKS.mixcloud} target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-orange-500 hover:bg-orange-600 rounded-full flex items-center justify-center text-white transition-colors">
                      <Radio className="w-5 h-5" />
                    </a>
                    <a href={SOCIAL_LINKS.tunein} target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center text-white transition-colors">
                      <Radio className="w-5 h-5" />
                    </a>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
          
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card>
              <CardContent className="p-8">
                <h3 className="font-semibold text-xl text-gray-900 mb-6">Send us a Message</h3>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Name (Required)</FormLabel>
                          <FormControl>
                            <Input placeholder="Your full name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email (Required)</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="your.email@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="subject"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Subject</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a topic..." />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="volunteering">Volunteering Opportunities</SelectItem>
                              <SelectItem value="presenting">Becoming a Presenter</SelectItem>
                              <SelectItem value="feedback">Feedback</SelectItem>
                              <SelectItem value="business">Business Enquiry</SelectItem>
                              <SelectItem value="technical">Technical Support</SelectItem>
                              <SelectItem value="general">General Enquiry</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Message</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us how we can help you..." 
                              rows={5}
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="consent"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel className="text-sm text-gray-600">
                              By submitting your information, you're giving us permission to email you. You may unsubscribe at any time.
                            </FormLabel>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                      disabled={form.formState.isSubmitting}
                    >
                      {form.formState.isSubmitting ? (
                        <>
                          <span className="animate-spin mr-2">⏳</span>
                          Sending...
                        </>
                      ) : (
                        <>
                          <Mail className="w-4 h-4 mr-2" />
                          Send Message
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};
