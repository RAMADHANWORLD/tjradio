import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { Calendar, Mic, Heart, Phone } from 'lucide-react';
import { RadioPlayer } from '@/components/RadioPlayer';
import { CONTACT_INFO } from '@/lib/constants';

export const Home = () => {
  const quickAccessItems = [
    { icon: Calendar, title: 'Schedule', description: 'View programming', href: '/schedule', color: 'from-primary to-primary/80' },
    { icon: Mic, title: 'Presenters', description: 'Meet our team', href: '/presenters', color: 'from-secondary to-secondary/80' },
    { icon: Heart, title: 'Volunteer', description: 'Get involved', href: '/about', color: 'from-accent to-accent/80' },
    { icon: Phone, title: 'Contact', description: 'Get in touch', href: '/contact', color: 'from-purple-500 to-purple-700' }
  ];

  return (
    <>
      {/* Hero Section */}
      <section className="min-h-screen flex items-center relative overflow-hidden">
        {/* Background Image with Overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')" }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-purple-900/60" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Hero Content */}
            <motion.div 
              className="text-white space-y-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="font-inter font-bold text-4xl md:text-6xl leading-tight">
                Rochdale's<br />
                <span className="bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">Community</span><br />
                Voice
              </h1>
              <p className="text-xl text-blue-100 max-w-lg">
                Broadcasting 24/7 on 97.0FM, serving our diverse community with local news, music, and Islamic programming since our launch.
              </p>
              <div className="flex flex-wrap gap-4">
                <button className="bg-primary hover:bg-primary/90 text-white px-8 py-3 rounded-full font-semibold transition-all hover:scale-105 flex items-center space-x-2">
                  <span>Listen Live</span>
                </button>
                <Link href="/about">
                  <button className="glass text-white px-8 py-3 rounded-full font-semibold hover:bg-white/20 transition-all">
                    Get Involved
                  </button>
                </Link>
              </div>
            </motion.div>
            
            {/* Live Radio Player */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <RadioPlayer />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Quick Access Buttons */}
      <section className="py-16 relative -mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {quickAccessItems.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Link href={item.href}>
                  <button className="glass rounded-xl p-6 text-center hover:scale-105 transition-all group w-full">
                    <div className={`w-12 h-12 bg-gradient-to-br ${item.color} rounded-full flex items-center justify-center mx-auto mb-3 group-hover:shadow-lg transition-all`}>
                      <item.icon className="text-white w-5 h-5" />
                    </div>
                    <h3 className="font-semibold text-gray-800">{item.title}</h3>
                    <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                  </button>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div 
              className="space-y-6"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <h2 className="font-inter font-bold text-3xl md:text-4xl text-gray-900">
                Welcome to <span className="text-primary">Crescent Community Radio</span>
              </h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                Rochdale's first and only full-time community radio station, broadcasting 24 hours a day, seven days a week on 97.0FM and online at crescentradio.net.
              </p>
              <p className="text-gray-600 leading-relaxed">
                We focus on serving our local Muslim community while welcoming participation from all community members. Our programming includes religious content, local news, community packages, and content in English and other community languages.
              </p>
              
              <div className="bg-gradient-to-r from-primary/10 to-blue-50 p-6 rounded-xl border-l-4 border-primary">
                <h3 className="font-semibold text-lg text-gray-900 mb-3">Want to Get Involved?</h3>
                <p className="text-gray-700 mb-4">
                  Maybe you'd like to present a show, or even help out behind the scenes. Full training will be provided and previous experience is not necessary.
                </p>
                <div className="flex flex-wrap gap-4">
                  <a href={`tel:${CONTACT_INFO.office.phone}`} className="inline-flex items-center space-x-2 text-primary hover:text-primary/80 font-medium">
                    <Phone className="w-4 h-4" />
                    <span>{CONTACT_INFO.office.phone}</span>
                  </a>
                  <a href={`mailto:${CONTACT_INFO.office.email}`} className="inline-flex items-center space-x-2 text-primary hover:text-primary/80 font-medium">
                    <span>{CONTACT_INFO.office.email}</span>
                  </a>
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.unsplash.com/photo-1559523161-0fc0d8b38a7a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Radio studio with community presenters" 
                className="rounded-2xl shadow-2xl w-full"
              />
              <div className="absolute -bottom-6 -left-6 glass rounded-xl p-4 shadow-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                  <span className="text-gray-800 font-medium">Broadcasting Live</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};
