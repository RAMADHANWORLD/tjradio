import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, Mic, Users, Settings } from 'lucide-react';
import { PRESENTERS, CONTACT_INFO } from '@/lib/constants';
import { AdminLogin } from '@/components/AdminLogin';
import { PresenterEditor } from '@/components/PresenterEditor';
import { Button } from '@/components/ui/button';

export const Presenters = () => {
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [presenters, setPresenters] = useState(PRESENTERS);

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    if (token) {
      // Verify token validity
      fetch('/api/auth/verify', {
        headers: { 'Authorization': `Bearer ${token}` }
      }).then(response => {
        if (response.ok) {
          setIsAdmin(true);
        } else {
          localStorage.removeItem('adminToken');
        }
      });
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    setIsAdmin(false);
    setShowLogin(false);
  };

  if (showLogin && !isAdmin) {
    return (
      <div className="min-h-screen py-20 bg-white flex items-center justify-center">
        <AdminLogin onLogin={setIsAdmin} />
      </div>
    );
  }

  if (isAdmin) {
    return (
      <div className="min-h-screen py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <PresenterEditor 
            presenters={presenters} 
            onUpdate={setPresenters}
            onLogout={handleLogout}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="font-inter font-bold text-4xl md:text-5xl text-gray-900 mb-4">Our Presenters</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">Meet the voices that bring our community together, sharing stories, music, and wisdom across Rochdale.</p>
        </motion.div>
        
        <div className="flex justify-end mb-4">
          <Button 
            variant="outline" 
            onClick={() => setShowLogin(true)}
            className="flex items-center space-x-2"
          >
            <Settings className="w-4 h-4" />
            <span>Admin</span>
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {presenters.map((presenter, index) => (
            <motion.div
              key={presenter.id}
              className="bg-gradient-to-br from-white to-blue-50 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all hover:scale-105"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="text-center">
                <img 
                  src={presenter.image} 
                  alt={`${presenter.name} - Radio Presenter`} 
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover border-4 border-white shadow-lg"
                />
                <h3 className="font-semibold text-xl text-gray-900">{presenter.name}</h3>
                <p className="text-primary font-medium mb-3">{presenter.role}</p>
                <p className="text-gray-600 text-sm mb-4">{presenter.shows}</p>
                <p className="text-xs text-gray-500 leading-relaxed mb-4">{presenter.bio}</p>
                
                <div className="flex justify-center space-x-3">
                  <Mic className="w-5 h-5 text-primary" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="bg-gradient-to-r from-accent/10 to-yellow-50 rounded-2xl p-8 max-w-2xl mx-auto">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <Users className="w-8 h-8 text-accent" />
              <h3 className="font-semibold text-xl text-gray-900">Join Our Team!</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Interested in becoming a presenter? We're always looking for passionate community members to join our team. 
              Full training provided, no experience necessary.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a 
                href={`tel:${CONTACT_INFO.office.phone}`} 
                className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-full font-semibold transition-colors flex items-center space-x-2"
              >
                <Phone className="w-4 h-4" />
                <span>{CONTACT_INFO.office.phone}</span>
              </a>
              <a 
                href={`mailto:${CONTACT_INFO.office.email}`} 
                className="bg-secondary hover:bg-secondary/90 text-white px-6 py-3 rounded-full font-semibold transition-colors flex items-center space-x-2"
              >
                <Mail className="w-4 h-4" />
                <span>{CONTACT_INFO.office.email}</span>
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
