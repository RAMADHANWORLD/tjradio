import { motion } from 'framer-motion';
import { Clock, Calendar, Plus } from 'lucide-react';
import { SCHEDULE_DATA } from '@/lib/constants';

export const Schedule = () => {
  const getColorClasses = (color: string) => {
    const colorMap = {
      primary: 'bg-primary/10 text-primary border-primary/20',
      secondary: 'bg-secondary/10 text-secondary border-secondary/20',
      accent: 'bg-accent/10 text-accent border-accent/20',
      purple: 'bg-purple-50 text-purple-700 border-purple-200',
      green: 'bg-green-50 text-green-700 border-green-200',
      blue: 'bg-blue-50 text-blue-700 border-blue-200',
      orange: 'bg-orange-50 text-orange-700 border-orange-200'
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.primary;
  };



  return (
    <div className="min-h-screen py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="font-inter font-bold text-4xl md:text-5xl text-gray-900 mb-4">Programming Schedule</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">Discover our diverse programming lineup featuring community voices, Islamic content, and local news.</p>
        </motion.div>
        
        <motion.div 
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="bg-gradient-to-r from-primary to-primary/80 p-6">
            <h2 className="font-semibold text-xl text-white text-center flex items-center justify-center space-x-2">
              <Calendar className="w-6 h-6" />
              <span>Current Weekly Schedule</span>
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-7 divide-y md:divide-y-0 md:divide-x divide-gray-200">
            {SCHEDULE_DATA.map((day, dayIndex) => (
              <motion.div 
                key={day.day}
                className="p-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: dayIndex * 0.1 }}
              >
                <h3 className="font-semibold text-center text-gray-900 mb-4">{day.day}</h3>
                <div className="space-y-3">
                  {day.shows.length > 0 ? (
                    day.shows.map((show, showIndex) => (
                      <motion.div 
                        key={showIndex}
                        className={`p-3 rounded-lg border ${getColorClasses(show.color)}`}
                        whileHover={{ scale: 1.02 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="flex items-center space-x-2 mb-1">
                          <Clock className="w-3 h-3" />
                          <div className="text-sm font-medium">{show.time}</div>
                        </div>
                        <div className="text-sm font-semibold">{show.name}</div>
                        <div className="text-xs opacity-75">{show.type}</div>
                      </motion.div>
                    ))
                  ) : (
                    <div className="text-center text-gray-500 mt-8">
                      <Plus className="w-8 h-8 mx-auto mb-2" />
                      <p className="text-sm">24/7 Music<br />& Community Content</p>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="bg-gray-50 p-6 text-center">
            <p className="text-gray-600 mb-4">Schedule updated June 2014. Current programming may vary.</p>
            <p className="text-sm text-gray-500">
              For real-time updates, call our studio at <strong>01706 340786</strong>
            </p>
          </div>
        </motion.div>

        {/* Additional Information */}
        <motion.div 
          className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="bg-white rounded-xl p-6 shadow-lg text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="text-white w-8 h-8" />
            </div>
            <h3 className="font-semibold text-lg text-gray-900 mb-2">24/7 Broadcasting</h3>
            <p className="text-gray-600 text-sm">Continuous programming with music and automated content when live shows aren't scheduled.</p>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-lg text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-secondary to-secondary/80 rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar className="text-white w-8 h-8" />
            </div>
            <h3 className="font-semibold text-lg text-gray-900 mb-2">Special Programs</h3>
            <p className="text-gray-600 text-sm">Religious observances, community events, and special broadcasts throughout the year.</p>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-lg text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-accent to-accent/80 rounded-full flex items-center justify-center mx-auto mb-4">
              <Plus className="text-white w-8 h-8" />
            </div>
            <h3 className="font-semibold text-lg text-gray-900 mb-2">Get Your Show</h3>
            <p className="text-gray-600 text-sm">Interested in hosting your own program? Contact us to discuss opportunities and training.</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
