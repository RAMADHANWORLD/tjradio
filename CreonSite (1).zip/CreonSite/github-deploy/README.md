# Crescent Community Radio Website

Modern React + TailwindCSS website for Crescent Community Radio 97.0FM - Rochdale's first and only full-time community radio station.

## GitHub Pages Deployment

This folder contains the production-ready static files for GitHub Pages deployment.

### To deploy to GitHub Pages:

1. **Upload to GitHub**:
   - Create a new GitHub repository
   - Upload all files from this `github-deploy` folder to the repository root
   - Make sure the repository is public (or you have GitHub Pro for private Pages)

2. **Enable GitHub Pages**:
   - Go to your repository settings
   - Scroll down to "Pages" section
   - Under "Source", select "Deploy from a branch"
   - Choose "main" branch and "/ (root)" folder
   - Click "Save"

3. **Your site will be available at**:
   `https://yourusername.github.io/your-repository-name`

## Features

- **Live Radio Streaming**: 24/7 broadcast from https://radio.canstream.co.uk:8152/live.mp3
- **Presenter Profiles**: 16 authentic presenter profiles with real photos
- **Weekly Schedule**: Complete programming schedule for all 7 days
- **Modern Design**: Glassmorphism effects with responsive layout
- **Contact Information**: All authentic contact details preserved

## Technical Details

- Built with React 18 + TypeScript
- Styled with TailwindCSS
- Animated with Framer Motion
- Optimized for production with Vite

## Contact

- **Studio Email**: studio@crescentradio.net
- **Phone**: 01706 340786
- **Website**: www.crescentradio.net

---
Built for manual GitHub deployment