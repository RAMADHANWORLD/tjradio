# Crescent Community Radio Website

## Overview

This is a modern React-based website for Crescent Community Radio 97.0FM, Rochdale's first and only full-time community radio station. The application provides a complete digital presence with live radio streaming, presenter information, programming schedules, and community engagement features. Built with React, TypeScript, and TailwindCSS, it offers a responsive, modern interface with glassmorphism design elements and smooth animations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing with pages for Home, About, Schedule, Presenters, and Contact
- **Styling**: TailwindCSS with custom design system featuring glassmorphism effects, modern gradients, and responsive layouts
- **UI Components**: Radix UI components with shadcn/ui for consistent, accessible interface elements
- **Animation**: Framer Motion for smooth page transitions, scroll animations, and interactive elements
- **State Management**: React Query (TanStack Query) for server state management and caching
- **Forms**: React Hook Form with Zod validation for type-safe form handling

### Backend Architecture
- **Server**: Express.js with TypeScript running in development and production modes
- **Build System**: Vite for fast development and optimized production builds with ESBuild for server bundling
- **Development**: Hot module replacement and error overlay integration for enhanced developer experience
- **API Structure**: RESTful API endpoints prefixed with `/api` for future backend functionality
- **Storage Interface**: Modular storage abstraction with in-memory implementation, designed for easy database integration

### Audio Streaming
- **Live Radio Player**: Custom HTML5 audio player with volume controls and animated equalizer visualization
- **Stream URL**: Direct integration with `https://radio.canstream.co.uk:8152/live.mp3` for 24/7 broadcasting
- **Player States**: Play/pause functionality with loading states and error handling
- **Floating Player**: Persistent compact player component for continuous listening across pages

### Design System
- **Typography**: Inter and Poppins font families for modern, readable text hierarchy
- **Color Palette**: CSS custom properties with primary blue, secondary orange, and accent colors
- **Components**: Reusable UI components with consistent spacing, shadows, and interactive states
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts and touch-optimized controls
- **Accessibility**: ARIA labels, semantic HTML, and keyboard navigation support

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React 18, React DOM, React Router (Wouter), React Query for modern React development
- **TypeScript**: Full TypeScript support across client and server with strict type checking
- **UI Framework**: Radix UI primitives for accessible component foundation with custom styling
- **Animation**: Framer Motion for declarative animations and gesture handling
- **Form Handling**: React Hook Form with Hookform Resolvers for validation integration

### Styling and Assets
- **TailwindCSS**: Utility-first CSS framework with custom configuration and dark mode support
- **PostCSS**: CSS processing with Autoprefixer for browser compatibility
- **Fonts**: Google Fonts integration (Inter, Poppins) for typography consistency
- **Icons**: Lucide React for consistent iconography throughout the application

### Development Tools
- **Vite**: Modern build tool with fast HMR and optimized production builds
- **ESBuild**: Fast bundling for server-side code compilation
- **TSX**: TypeScript execution for development server running
- **Replit Integration**: Development environment integration with runtime error handling

### Database and Storage
- **Drizzle ORM**: Type-safe database operations with PostgreSQL dialect configuration
- **Neon Database**: Serverless PostgreSQL integration via `@neondatabase/serverless`
- **Schema Management**: Drizzle Kit for database migrations and schema management
- **Session Storage**: Connect-pg-simple for PostgreSQL session storage capability

### Validation and Utilities
- **Zod**: Runtime type validation for forms and API data
- **Drizzle-Zod**: Integration between Drizzle schemas and Zod validation
- **Class Variance Authority**: Type-safe CSS class composition for component variants
- **CLSX**: Utility for conditional CSS class handling
- **Date-fns**: Modern date manipulation and formatting library