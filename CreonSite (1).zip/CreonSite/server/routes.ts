import type { Express } from "express";
import { createServer, type Server } from "http";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { storage } from "./storage";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Middleware to verify admin token
const verifyAdmin = (req: any, res: any, next: any) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    
    try {
      const user = await storage.getUserByUsername(username);
      
      if (!user || !await bcrypt.compare(password, user.password)) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '24h' });
      res.json({ token, user: { id: user.id, username: user.username } });
    } catch (error) {
      res.status(500).json({ error: 'Login failed' });
    }
  });

  app.get('/api/auth/verify', verifyAdmin, (req, res) => {
    res.json({ valid: true, user: req.user });
  });

  // Presenter management routes
  app.get('/api/presenters', (req, res) => {
    // Return presenters from database or constants
    res.json({ presenters: [] }); // You'll need to implement presenter storage
  });

  // Setup page for creating first admin user
  app.get('/setup', (req, res) => {
    res.send(`
      <!DOCTYPE html>
      <html>
      <head><title>Admin Setup</title></head>
      <body style="font-family: Arial; max-width: 400px; margin: 50px auto; padding: 20px;">
        <h2>Create Admin User</h2>
        <form method="POST" action="/api/auth/setup">
          <div style="margin-bottom: 15px;">
            <label>Username:</label><br>
            <input type="text" name="username" required style="width: 100%; padding: 8px;">
          </div>
          <div style="margin-bottom: 15px;">
            <label>Password:</label><br>
            <input type="password" name="password" required style="width: 100%; padding: 8px;">
          </div>
          <button type="submit" style="padding: 10px 20px; background: #007bff; color: white; border: none;">
            Create Admin
          </button>
        </form>
      </body>
      </html>
    `);
  });

  app.put('/api/presenters', verifyAdmin, async (req, res) => {
    try {
      const { id, ...presenterData } = req.body;
      // Update presenter in database
      // await storage.updatePresenter(id, presenterData);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update presenter' });
    }
  });

  app.delete('/api/presenters/:id', verifyAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      // Delete presenter from database
      // await storage.deletePresenter(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete presenter' });
    }
  });

  // Create default admin user if it doesn't exist
  app.post('/api/auth/setup', async (req, res) => {
    try {
      const { username, password } = req.body;
      const hashedPassword = await bcrypt.hash(password, 10);
      
      const user = await storage.createUser({
        username,
        password: hashedPassword
      });
      
      res.json({ success: true, userId: user.id });
    } catch (error) {
      res.status(500).json({ error: 'Setup failed' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
